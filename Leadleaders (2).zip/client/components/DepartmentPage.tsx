import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { mockTickets, Department } from '@/lib/types';
import {
  Users,
  TicketIcon,
  Clock,
  AlertCircle,
  CheckCircle,
  TrendingUp,
  Mail,
  Phone,
  Calendar,
  BarChart3,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface DepartmentPageProps {
  department: Department;
}

export default function DepartmentPage({ department }: DepartmentPageProps) {
  const departmentTickets = mockTickets.filter(ticket => ticket.department === department.id);
  
  const stats = {
    total: departmentTickets.length,
    open: departmentTickets.filter(t => t.status === 'open').length,
    inProgress: departmentTickets.filter(t => t.status === 'in-progress').length,
    resolved: departmentTickets.filter(t => t.status === 'resolved').length,
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-red-100 text-red-800 border-red-200';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'closed': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open': return <AlertCircle className="h-4 w-4" />;
      case 'in-progress': return <Clock className="h-4 w-4" />;
      case 'resolved': return <CheckCircle className="h-4 w-4" />;
      case 'closed': return <CheckCircle className="h-4 w-4" />;
      default: return <TicketIcon className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className={cn('p-3 rounded-xl text-white', department.color)}>
          <Users className="h-8 w-8" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-foreground">{department.name}</h1>
          <p className="text-muted-foreground">{department.description}</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي التذاكر</CardTitle>
            <TicketIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
            <p className="text-xs text-muted-foreground">في هذا القسم</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">المفتوحة</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.open}</div>
            <p className="text-xs text-muted-foreground">تحتاج إلى معالجة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">قيد المعالجة</CardTitle>
            <Clock className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.inProgress}</div>
            <p className="text-xs text-muted-foreground">جاري العمل عليها</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">تم الحل</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.resolved}</div>
            <p className="text-xs text-muted-foreground">تم إنجازها</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Tickets Section */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تذاكر {department.name}</CardTitle>
              <CardDescription>جميع التذاكر الخاصة بهذا القسم</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {departmentTickets.length > 0 ? (
                departmentTickets.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 transition-colors">
                    <div className="flex items-start gap-3">
                      <div className={cn('p-2 rounded-lg', getPriorityColor(ticket.priority))}>
                        {getStatusIcon(ticket.status)}
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium">{ticket.title}</h4>
                        <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className={getStatusColor(ticket.status)}>
                            {ticket.status === 'open' ? 'مفتوح' :
                             ticket.status === 'in-progress' ? 'قيد المعالجة' :
                             ticket.status === 'resolved' ? 'محلول' : 'مغلق'}
                          </Badge>
                          <span className="text-xs text-muted-foreground">#{ticket.id}</span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {ticket.createdAt.toLocaleDateString('ar-EG')}
                          </span>
                        </div>
                        {ticket.tags && (
                          <div className="flex gap-1">
                            {ticket.tags.map((tag, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-left">
                      {ticket.assignee && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Avatar className="h-6 w-6">
                            <AvatarFallback className="text-xs">{ticket.assignee[0]}</AvatarFallback>
                          </Avatar>
                          {ticket.assignee}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <TicketIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <h3 className="font-medium">لا توجد تذاكر حالياً</h3>
                  <p className="text-sm">لم يتم إنشاء أي تذاكر لهذا القسم بعد</p>
                  <Button className="mt-4">إنشاء تذكرة جديدة</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Team Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                معلومات الفريق
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">عدد أعضاء الفريق</span>
                <span className="font-medium">{department.teamSize}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">التذاكر النشطة</span>
                <span className="font-medium">{stats.open + stats.inProgress}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">معدل الحل</span>
                <span className="font-medium">
                  {stats.total > 0 ? Math.round((stats.resolved / stats.total) * 100) : 0}%
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                الأداء
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>معدل الحل</span>
                  <span>{stats.total > 0 ? Math.round((stats.resolved / stats.total) * 100) : 0}%</span>
                </div>
                <Progress value={stats.total > 0 ? (stats.resolved / stats.total) * 100 : 0} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>الاستجابة السريعة</span>
                  <span>92%</span>
                </div>
                <Progress value={92} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>رضا العملاء</span>
                  <span>89%</span>
                </div>
                <Progress value={89} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>إجراءات سريعة</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start gap-2">
                <TicketIcon className="h-4 w-4" />
                إنشاء تذكرة جديدة
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2">
                <Mail className="h-4 w-4" />
                إرسال تقرير
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2">
                <Users className="h-4 w-4" />
                إدارة الفريق
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
