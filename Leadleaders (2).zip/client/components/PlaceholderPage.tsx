import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import {
  ArrowLeft,
  Mail,
  Phone,
  Calendar,
  MessageCircle,
} from 'lucide-react';

interface PlaceholderPageProps {
  title: string;
  description: string;
  comingSoonText?: string;
  icon?: React.ReactNode;
}

export default function PlaceholderPage({ 
  title, 
  description, 
  comingSoonText = "This page is currently under development. Check back soon for updates!",
  icon 
}: PlaceholderPageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <Badge variant="outline" className="w-fit mx-auto">Coming Soon</Badge>
            <div className="flex justify-center mb-6">
              {icon && (
                <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center text-primary-foreground">
                  {icon}
                </div>
              )}
            </div>
            <h1 className="text-4xl font-bold sm:text-5xl lg:text-6xl">
              {title}
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              {description}
            </p>
          </div>
        </div>
      </section>

      {/* Coming Soon Content */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto">
            <Card className="p-8 text-center">
              <CardHeader className="p-0 mb-6">
                <CardTitle className="text-2xl">Page Under Development</CardTitle>
                <CardDescription className="text-lg">
                  {comingSoonText}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0 space-y-6">
                <div className="w-24 h-24 bg-muted rounded-full mx-auto flex items-center justify-center">
                  <Calendar className="h-12 w-12 text-muted-foreground" />
                </div>
                
                <p className="text-muted-foreground">
                  We're working hard to bring you an amazing experience. 
                  In the meantime, feel free to explore our other pages or contact us directly.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                  <Button className="gap-2" asChild>
                    <Link to="/">
                      <ArrowLeft className="h-4 w-4" />
                      Back to Home
                    </Link>
                  </Button>
                  <Button variant="outline" className="gap-2" asChild>
                    <Link to="/contact">
                      <Mail className="h-4 w-4" />
                      Contact Us
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Quick Contact */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center space-y-4 mb-12">
              <h2 className="text-3xl font-bold">
                Need Immediate Assistance?
              </h2>
              <p className="text-xl text-muted-foreground">
                Don't wait! Reach out to us today and let's discuss your business needs.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="p-6">
                <CardContent className="p-0 text-center">
                  <Phone className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Call Us Today</h3>
                  <p className="text-muted-foreground mb-4">
                    Speak directly with our team
                  </p>
                  <Button variant="outline" className="gap-2">
                    <Phone className="h-4 w-4" />
                    +1 (555) 123-4567
                  </Button>
                </CardContent>
              </Card>

              <Card className="p-6">
                <CardContent className="p-0 text-center">
                  <MessageCircle className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Send a Message</h3>
                  <p className="text-muted-foreground mb-4">
                    Get a detailed response via email
                  </p>
                  <Button variant="outline" className="gap-2" asChild>
                    <Link to="/contact">
                      <Mail className="h-4 w-4" />
                      Contact Form
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
