import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Home,
  Building,
  Users,
  Briefcase,
  Trophy,
  Mail,
  Menu,
  Phone,
} from 'lucide-react';

const navigation = [
  { name: 'Home', path: '/', icon: Home },
  { name: 'About Us', path: '/about', icon: Building },
  { name: 'Services', path: '/services', icon: Briefcase },
  { name: 'Team', path: '/team', icon: Users },
  { name: 'Portfolio', path: '/portfolio', icon: Trophy },
  { name: 'Support', path: '/support', icon: Phone },
  { name: 'Contact', path: '/contact', icon: Mail },
];

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  const Navigation = () => (
    <nav className="flex space-x-8">
      {navigation.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          className={cn(
            'flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary',
            location.pathname === item.path 
              ? 'text-primary' 
              : 'text-muted-foreground'
          )}
        >
          {item.name}
        </Link>
      ))}
    </nav>
  );

  const MobileNavigation = () => (
    <nav className="space-y-4">
      {navigation.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          onClick={() => setIsMobileMenuOpen(false)}
          className={cn(
            'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent',
            location.pathname === item.path 
              ? 'bg-accent text-accent-foreground' 
              : 'text-muted-foreground'
          )}
        >
          <item.icon className="h-4 w-4" />
          {item.name}
        </Link>
      ))}
    </nav>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <img 
              src="https://cdn.builder.io/api/v1/image/assets%2Fc0b5dede6cf14c76b391d16bf0c6c54e%2F35def15e908244ee914d6d06c2b4282b?format=webp&width=800" 
              alt="Leadleaders" 
              className="h-10 w-auto"
            />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex">
            <Navigation />
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="gap-2">
              <Phone className="h-4 w-4" />
              +1 (555) 123-4567
            </Button>
            <Button size="sm" className="gap-2">
              <Mail className="h-4 w-4" />
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64 p-0">
              <div className="flex h-full flex-col">
                <div className="p-6">
                  <img 
                    src="https://cdn.builder.io/api/v1/image/assets%2Fc0b5dede6cf14c76b391d16bf0c6c54e%2F35def15e908244ee914d6d06c2b4282b?format=webp&width=800" 
                    alt="Leadleaders" 
                    className="h-8 w-auto"
                  />
                </div>
                <div className="flex-1 px-6">
                  <MobileNavigation />
                </div>
                <div className="p-6 space-y-3">
                  <Button variant="outline" size="sm" className="w-full gap-2">
                    <Phone className="h-4 w-4" />
                    Call Us
                  </Button>
                  <Button size="sm" className="w-full gap-2">
                    <Mail className="h-4 w-4" />
                    Get Quote
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main content */}
      <main>
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/50">
        <div className="container mx-auto px-6 py-12">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="space-y-4">
              <img 
                src="https://cdn.builder.io/api/v1/image/assets%2Fc0b5dede6cf14c76b391d16bf0c6c54e%2F35def15e908244ee914d6d06c2b4282b?format=webp&width=800" 
                alt="Leadleaders" 
                className="h-10 w-auto"
              />
              <p className="text-sm text-muted-foreground max-w-xs">
                Leading the way in innovative business solutions and strategic consulting services.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/services" className="hover:text-primary">Business Consulting</Link></li>
                <li><Link to="/services" className="hover:text-primary">Strategic Planning</Link></li>
                <li><Link to="/services" className="hover:text-primary">Digital Solutions</Link></li>
                <li><Link to="/services" className="hover:text-primary">Project Management</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/about" className="hover:text-primary">About Us</Link></li>
                <li><Link to="/team" className="hover:text-primary">Our Team</Link></li>
                <li><Link to="/portfolio" className="hover:text-primary">Portfolio</Link></li>
                <li><Link to="/contact" className="hover:text-primary">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  +1 (555) 123-4567
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  info@leadleaders.com
                </li>
                <li>
                  123 Business Avenue<br />
                  New York, NY 10001
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Leadleaders. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
