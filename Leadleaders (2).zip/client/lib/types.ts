export interface Ticket {
  id: string;
  title: string;
  description: string;
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  department: string;
  assignee?: string;
  requester: string;
  createdAt: Date;
  updatedAt: Date;
  tags?: string[];
}

export interface Department {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  color: string;
  description: string;
  ticketCount: number;
  teamSize: number;
}

export interface DashboardStats {
  totalTickets: number;
  openTickets: number;
  inProgressTickets: number;
  resolvedTickets: number;
  avgResolutionTime: number;
}

// Mock data for development
export const mockTickets: Ticket[] = [
  {
    id: '1',
    title: 'مشكلة في تسجيل الدخول للموظفين الجدد',
    description: 'الموظفون الجدد لا يستطيعو�� الوصول إلى النظام',
    status: 'open',
    priority: 'high',
    department: 'hr',
    requester: 'محمد أحمد',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15'),
    tags: ['تقنية', 'عاجل']
  },
  {
    id: '2',
    title: 'طلب تحديث بيانات العميل',
    description: 'العميل يريد تحديث معلومات الاتصال',
    status: 'in-progress',
    priority: 'medium',
    department: 'csm',
    assignee: 'سارة محمد',
    requester: 'أحمد علي',
    createdAt: new Date('2024-01-14'),
    updatedAt: new Date('2024-01-15'),
    tags: ['عميل', 'تحديث']
  },
  {
    id: '3',
    title: 'مراجعة استراتيجية التسويق الرقمي',
    description: 'تحليل أداء الحملات الإعلانية الحالية',
    status: 'resolved',
    priority: 'medium',
    department: 'marketing',
    assignee: 'ليلى حسن',
    requester: 'المدير التنفيذي',
    createdAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-01-14'),
    tags: ['استراتيجية', 'تحليل']
  },
  {
    id: '4',
    title: 'اختبار الميزة الجديدة في التطبيق',
    description: 'فحص شامل للميزات الجديدة قبل الإطلاق',
    status: 'in-progress',
    priority: 'urgent',
    department: 'qa',
    assignee: 'عمر يوسف',
    requester: 'فريق التطوير',
    createdAt: new Date('2024-01-13'),
    updatedAt: new Date('2024-01-15'),
    tags: ['اختبار', 'تطوير']
  },
  {
    id: '5',
    title: 'تقرير مبيعات الربع الأول',
    description: 'إعداد تقرير شامل عن أداء المبيعات',
    status: 'open',
    priority: 'low',
    department: 'sales',
    requester: 'رانيا خالد',
    createdAt: new Date('2024-01-12'),
    updatedAt: new Date('2024-01-12'),
    tags: ['تقرير', 'مبيعات']
  }
];

export const departments: Department[] = [
  {
    id: 'hr',
    name: 'الموارد البشرية',
    nameEn: 'Human Resources',
    icon: 'Users',
    color: 'bg-blue-500',
    description: 'إدارة شؤون الموظفين والتوظيف',
    ticketCount: 12,
    teamSize: 5
  },
  {
    id: 'sales',
    name: 'المبيعات',
    nameEn: 'Sales',
    icon: 'TrendingUp',
    color: 'bg-green-500',
    description: 'إدارة المبيعات وخدمة العملاء',
    ticketCount: 18,
    teamSize: 8
  },
  {
    id: 'csm',
    name: 'خدمة العملاء',
    nameEn: 'Customer Success',
    icon: 'UserCheck',
    color: 'bg-purple-500',
    description: 'ضمان رضا العملاء ونجاحهم',
    ticketCount: 24,
    teamSize: 6
  },
  {
    id: 'business-development',
    name: 'تطوير الأعمال',
    nameEn: 'Business Development',
    icon: 'Briefcase',
    color: 'bg-orange-500',
    description: 'تطوير الفرص التجارية والشراكات',
    ticketCount: 9,
    teamSize: 4
  },
  {
    id: 'marketing',
    name: 'التسويق',
    nameEn: 'Marketing',
    icon: 'Megaphone',
    color: 'bg-pink-500',
    description: 'التسويق والعلامة التجارية',
    ticketCount: 15,
    teamSize: 7
  },
  {
    id: 'qa',
    name: 'ضمان الجودة',
    nameEn: 'Quality Assurance',
    icon: 'TestTube',
    color: 'bg-indigo-500',
    description: 'ضمان جودة المنتجات والخدمات',
    ticketCount: 8,
    teamSize: 3
  }
];
