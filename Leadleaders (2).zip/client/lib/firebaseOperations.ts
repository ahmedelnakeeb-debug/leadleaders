import { 
  collection, 
  addDoc, 
  getDocs, 
  doc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  where,
  Timestamp,
  onSnapshot
} from 'firebase/firestore';
import { db } from './firebase';

// Type definitions for tickets
export interface Ticket {
  id?: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  contactName: string;
  contactEmail: string;
  createdAt: Date;
  updatedAt: Date;
  assignedTo?: string;
  notes?: string[];
}

export interface CreateTicketData {
  title: string;
  description: string;
  category: string;
  priority: string;
  contactName: string;
  contactEmail: string;
}

// Collection reference
const TICKETS_COLLECTION = 'tickets';

// Create a new ticket
export const createTicket = async (ticketData: CreateTicketData): Promise<string> => {
  try {
    const now = new Date();
    const ticket = {
      ...ticketData,
      status: 'open' as const,
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now),
      notes: []
    };

    console.log('Creating ticket with data:', ticket);

    const docRef = await addDoc(collection(db, TICKETS_COLLECTION), ticket);

    console.log('Ticket created with ID: ', docRef.id);
    return docRef.id;
  } catch (error) {
    console.error('Error creating ticket: ', error);
    console.error('Error details:', error);
    throw error;
  }
};

// Get all tickets
export const getAllTickets = async (): Promise<Ticket[]> => {
  try {
    console.log('Fetching tickets from collection:', TICKETS_COLLECTION);

    const q = query(
      collection(db, TICKETS_COLLECTION),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    const tickets: Ticket[] = [];

    console.log('Found tickets:', querySnapshot.size);

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      console.log('Processing ticket:', doc.id, data);

      tickets.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(data.createdAt),
        updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : new Date(data.updatedAt)
      } as Ticket);
    });

    console.log('Processed tickets:', tickets.length);
    return tickets;
  } catch (error) {
    console.error('Error getting tickets: ', error);
    throw error;
  }
};

// Get tickets by email
export const getTicketsByEmail = async (email: string): Promise<Ticket[]> => {
  try {
    const q = query(
      collection(db, TICKETS_COLLECTION),
      where('contactEmail', '==', email),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const tickets: Ticket[] = [];

    querySnapshot.forEach((doc) => {
      const data = doc.data();
      tickets.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt.toDate(),
        updatedAt: data.updatedAt.toDate()
      } as Ticket);
    });

    return tickets;
  } catch (error) {
    console.error('Error getting tickets by email: ', error);
    throw error;
  }
};

// Update ticket status
export const updateTicketStatus = async (ticketId: string, status: Ticket['status']): Promise<void> => {
  try {
    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    await updateDoc(ticketRef, {
      status,
      updatedAt: Timestamp.fromDate(new Date())
    });
    console.log('Ticket status updated successfully');
  } catch (error) {
    console.error('Error updating ticket status: ', error);
    throw error;
  }
};

// Add note to ticket
export const addNoteToTicket = async (ticketId: string, note: string): Promise<void> => {
  try {
    const ticketRef = doc(db, TICKETS_COLLECTION, ticketId);
    
    // First get the current ticket to access existing notes
    const ticketDoc = await getDocs(query(collection(db, TICKETS_COLLECTION), where('__name__', '==', ticketId)));
    
    if (!ticketDoc.empty) {
      const currentData = ticketDoc.docs[0].data();
      const currentNotes = currentData.notes || [];
      
      await updateDoc(ticketRef, {
        notes: [...currentNotes, {
          text: note,
          timestamp: Timestamp.fromDate(new Date()),
          author: 'Support Team'
        }],
        updatedAt: Timestamp.fromDate(new Date())
      });
      console.log('Note added to ticket successfully');
    }
  } catch (error) {
    console.error('Error adding note to ticket: ', error);
    throw error;
  }
};

// Listen to tickets in real-time
export const listenToTickets = (callback: (tickets: Ticket[]) => void) => {
  const q = query(
    collection(db, TICKETS_COLLECTION), 
    orderBy('createdAt', 'desc')
  );

  return onSnapshot(q, (querySnapshot) => {
    const tickets: Ticket[] = [];
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      tickets.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt.toDate(),
        updatedAt: data.updatedAt.toDate()
      } as Ticket);
    });
    callback(tickets);
  });
};

// Delete ticket (admin only)
export const deleteTicket = async (ticketId: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, TICKETS_COLLECTION, ticketId));
    console.log('Ticket deleted successfully');
  } catch (error) {
    console.error('Error deleting ticket: ', error);
    throw error;
  }
};

// Get ticket statistics
export const getTicketStats = async () => {
  try {
    const tickets = await getAllTickets();
    
    return {
      total: tickets.length,
      open: tickets.filter(t => t.status === 'open').length,
      inProgress: tickets.filter(t => t.status === 'in-progress').length,
      resolved: tickets.filter(t => t.status === 'resolved').length,
      closed: tickets.filter(t => t.status === 'closed').length,
      highPriority: tickets.filter(t => t.priority === 'high' || t.priority === 'urgent').length
    };
  } catch (error) {
    console.error('Error getting ticket stats: ', error);
    throw error;
  }
};
