import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// Firebase configuration
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBUixRYUho5_XvvehWBZdDMXS9-xK6o_9E",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "leadleaders-27c23.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "leadleaders-27c23",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "leadleaders-27c23.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "194591935203",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:194591935203:web:5befbef5ebcc09fb5053d6",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-YGR0X7M0PN"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);

export default app;
