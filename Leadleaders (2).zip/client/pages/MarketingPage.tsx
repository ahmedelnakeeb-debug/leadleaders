import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function MarketingPage() {
  const marketingDepartment = departments.find(dept => dept.id === 'marketing')!;
  return <DepartmentPage department={marketingDepartment} />;
}
