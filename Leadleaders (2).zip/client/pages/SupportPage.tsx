import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  TicketIcon,
  Plus,
  Search,
  MessageCircle,
  AlertCircle,
  CheckCircle,
  Clock,
  Phone,
  Mail,
  FileText,
  Send,
  User,
  RefreshCw,
} from 'lucide-react';

// Import Firebase operations
import { 
  createTicket, 
  getAllTickets, 
  getTicketsByEmail,
  listenToTickets,
  Ticket,
  CreateTicketData 
} from '@/lib/firebaseOperations';

export default function SupportPage() {
  const [newTicket, setNewTicket] = useState<CreateTicketData>({
    title: '',
    description: '',
    category: '',
    priority: '',
    contactEmail: '',
    contactName: ''
  });

  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [emailSearch, setEmailSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Load tickets on component mount
  useEffect(() => {
    loadTickets();
    
    // Set up real-time listener
    const unsubscribe = listenToTickets((updatedTickets) => {
      setTickets(updatedTickets);
    });

    // Cleanup listener on unmount
    return () => unsubscribe();
  }, []);

  const loadTickets = async () => {
    setLoading(true);
    setError(null);
    try {
      const allTickets = await getAllTickets();
      setTickets(allTickets);
    } catch (err) {
      setError('Failed to load tickets. Please try again.');
      console.error('Error loading tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  const searchTicketsByEmail = async () => {
    if (!emailSearch.trim()) {
      loadTickets();
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const userTickets = await getTicketsByEmail(emailSearch);
      setTickets(userTickets);
    } catch (err) {
      setError('Failed to search tickets. Please try again.');
      console.error('Error searching tickets:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-red-100 text-red-800 border-red-200';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'resolved': return 'bg-green-100 text-green-800 border-green-200';
      case 'closed': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'open': return <AlertCircle className="h-4 w-4" />;
      case 'in-progress': return <Clock className="h-4 w-4" />;
      case 'resolved': return <CheckCircle className="h-4 w-4" />;
      case 'closed': return <CheckCircle className="h-4 w-4" />;
      default: return <TicketIcon className="h-4 w-4" />;
    }
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setSuccess(null);

    // Validate required fields
    if (!newTicket.contactName.trim() || !newTicket.contactEmail.trim() ||
        !newTicket.title.trim() || !newTicket.description.trim() ||
        !newTicket.category || !newTicket.priority) {
      setError('Please fill in all required fields.');
      setSubmitting(false);
      return;
    }

    try {
      console.log('Submitting ticket:', newTicket);
      const ticketId = await createTicket(newTicket);
      setSuccess(`Ticket created successfully! Ticket ID: TKT-${ticketId.slice(-6).toUpperCase()}`);

      // Reset form
      setNewTicket({
        title: '',
        description: '',
        category: '',
        priority: '',
        contactEmail: '',
        contactName: ''
      });

      // Refresh tickets list
      loadTickets();
    } catch (err: any) {
      console.error('Error submitting ticket:', err);
      const errorMessage = err?.message || 'Failed to submit ticket. Please try again.';
      setError(`Error: ${errorMessage}`);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredTickets = tickets.filter(ticket =>
    ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ticket.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (ticket.id && ticket.id.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <Badge variant="outline" className="w-fit mx-auto">Customer Support</Badge>
            <h1 className="text-4xl font-bold sm:text-5xl">
              How Can We Help You?
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Submit a support ticket, track your existing requests, or browse our help resources. 
              Our team is here to assist you with any questions or concerns.
            </p>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <Tabs defaultValue="submit" className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="submit" className="gap-2">
                <Plus className="h-4 w-4" />
                Submit Ticket
              </TabsTrigger>
              <TabsTrigger value="track" className="gap-2">
                <Search className="h-4 w-4" />
                Track Tickets
              </TabsTrigger>
              <TabsTrigger value="help" className="gap-2">
                <MessageCircle className="h-4 w-4" />
                Help Center
              </TabsTrigger>
            </TabsList>

            {/* Submit Ticket Tab */}
            <TabsContent value="submit" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TicketIcon className="h-5 w-5" />
                    Submit a New Support Ticket
                  </CardTitle>
                  <CardDescription>
                    Fill out the form below and we'll get back to you as soon as possible.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {error && (
                    <Alert className="mb-6 border-red-200 bg-red-50">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-red-800">{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  {success && (
                    <Alert className="mb-6 border-green-200 bg-green-50">
                      <CheckCircle className="h-4 w-4" />
                      <AlertDescription className="text-green-800">{success}</AlertDescription>
                    </Alert>
                  )}

                  <form onSubmit={handleSubmitTicket} className="space-y-6">
                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="contactName">Full Name *</Label>
                        <Input
                          id="contactName"
                          placeholder="Enter your full name"
                          value={newTicket.contactName}
                          onChange={(e) => setNewTicket({...newTicket, contactName: e.target.value})}
                          required
                          disabled={submitting}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="contactEmail">Email Address *</Label>
                        <Input
                          id="contactEmail"
                          type="email"
                          placeholder="Enter your email"
                          value={newTicket.contactEmail}
                          onChange={(e) => setNewTicket({...newTicket, contactEmail: e.target.value})}
                          required
                          disabled={submitting}
                        />
                      </div>
                    </div>

                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="category">Category *</Label>
                        <Select 
                          value={newTicket.category} 
                          onValueChange={(value) => setNewTicket({...newTicket, category: value})}
                          disabled={submitting}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="technical">Technical Support</SelectItem>
                            <SelectItem value="billing">Billing & Payments</SelectItem>
                            <SelectItem value="general">General Inquiry</SelectItem>
                            <SelectItem value="complaint">Complaint</SelectItem>
                            <SelectItem value="feature">Feature Request</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="priority">Priority *</Label>
                        <Select 
                          value={newTicket.priority} 
                          onValueChange={(value) => setNewTicket({...newTicket, priority: value})}
                          disabled={submitting}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="urgent">Urgent</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="title">Subject *</Label>
                      <Input
                        id="title"
                        placeholder="Brief description of your issue"
                        value={newTicket.title}
                        onChange={(e) => setNewTicket({...newTicket, title: e.target.value})}
                        required
                        disabled={submitting}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="description">Description *</Label>
                      <Textarea
                        id="description"
                        placeholder="Please provide detailed information about your issue or request..."
                        className="min-h-32"
                        value={newTicket.description}
                        onChange={(e) => setNewTicket({...newTicket, description: e.target.value})}
                        required
                        disabled={submitting}
                      />
                    </div>

                    <Button type="submit" size="lg" className="gap-2" disabled={submitting}>
                      {submitting ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          Submit Ticket
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Track Tickets Tab */}
            <TabsContent value="track" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        <Search className="h-5 w-5" />
                        Track Your Support Tickets
                      </CardTitle>
                      <CardDescription>
                        Search and view the status of your submitted tickets.
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={loadTickets} disabled={loading}>
                      <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search tickets by ID, title, or description..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Search by email address"
                        value={emailSearch}
                        onChange={(e) => setEmailSearch(e.target.value)}
                      />
                      <Button onClick={searchTicketsByEmail} disabled={loading}>
                        Search
                      </Button>
                    </div>
                  </div>

                  {loading && (
                    <div className="text-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                      <p className="text-muted-foreground">Loading tickets...</p>
                    </div>
                  )}

                  {!loading && (
                    <div className="space-y-4">
                      {filteredTickets.map((ticket) => (
                        <Card key={ticket.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-6">
                            <div className="flex items-start justify-between mb-4">
                              <div className="space-y-2">
                                <div className="flex items-center gap-3">
                                  <Badge variant="outline" className="font-mono">
                                    TKT-{ticket.id?.slice(-6).toUpperCase()}
                                  </Badge>
                                  <Badge variant="outline" className={getStatusColor(ticket.status)}>
                                    <span className="flex items-center gap-1">
                                      {getStatusIcon(ticket.status)}
                                      {ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1).replace('-', ' ')}
                                    </span>
                                  </Badge>
                                  <span className={`text-sm font-medium ${getPriorityColor(ticket.priority)}`}>
                                    {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)} Priority
                                  </span>
                                </div>
                                <h3 className="text-lg font-semibold">{ticket.title}</h3>
                                <p className="text-muted-foreground">{ticket.description}</p>
                                <div className="text-sm text-muted-foreground">
                                  <p>Contact: {ticket.contactName} ({ticket.contactEmail})</p>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center justify-between text-sm text-muted-foreground">
                              <span>Category: {ticket.category}</span>
                              <div className="flex gap-4">
                                <span>Created: {ticket.createdAt.toLocaleDateString()}</span>
                                <span>Updated: {ticket.updatedAt.toLocaleDateString()}</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {!loading && filteredTickets.length === 0 && (
                    <div className="text-center py-12 text-muted-foreground">
                      <TicketIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <h3 className="font-medium">No tickets found</h3>
                      <p className="text-sm">Try adjusting your search terms or submit a new ticket.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Help Center Tab */}
            <TabsContent value="help" className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Phone className="h-5 w-5" />
                      Contact Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="font-medium">Phone Support</div>
                        <div className="text-sm text-muted-foreground">+1 (555) 123-4567</div>
                        <div className="text-xs text-muted-foreground">Mon-Fri, 9 AM - 6 PM EST</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="font-medium">Email Support</div>
                        <div className="text-sm text-muted-foreground">support@leadleaders.com</div>
                        <div className="text-xs text-muted-foreground">Response within 24 hours</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-5 w-5" />
                      Quick Links
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="ghost" className="w-full justify-start" asChild>
                      <Link to="/services">
                        <FileText className="h-4 w-4 mr-2" />
                        Service Documentation
                      </Link>
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" asChild>
                      <Link to="/about">
                        <User className="h-4 w-4 mr-2" />
                        About Leadleaders
                      </Link>
                    </Button>
                    <Button variant="ghost" className="w-full justify-start" asChild>
                      <Link to="/contact">
                        <Mail className="h-4 w-4 mr-2" />
                        General Contact
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-l-4 border-primary pl-4">
                    <h4 className="font-medium">How quickly do you respond to support tickets?</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      We aim to respond to all tickets within 24 hours during business days. 
                      High priority and urgent tickets are typically addressed within 4 hours.
                    </p>
                  </div>
                  <div className="border-l-4 border-primary pl-4">
                    <h4 className="font-medium">What information should I include in my ticket?</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Please provide as much detail as possible including: your contact information, 
                      a clear description of the issue, steps to reproduce (if applicable), and any error messages.
                    </p>
                  </div>
                  <div className="border-l-4 border-primary pl-4">
                    <h4 className="font-medium">Can I update my ticket after submission?</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      Yes, you can reply to the email confirmation you receive, or contact us directly 
                      with your ticket ID to provide additional information.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
