import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Users,
  Target,
  TrendingUp,
  Briefcase,
  CheckCircle,
  Star,
  Phone,
  Mail,
  MapPin,
  Award,
  Globe,
  Zap,
  TicketIcon,
} from 'lucide-react';

export default function Index() {
  const services = [
    {
      icon: Target,
      title: "Strategic Consulting",
      description: "Expert guidance to help your business achieve its strategic objectives and sustainable growth.",
      features: ["Market Analysis", "Business Planning", "Growth Strategy"]
    },
    {
      icon: TrendingUp,
      title: "Business Development",
      description: "Accelerate your business growth with our comprehensive development solutions.",
      features: ["Lead Generation", "Partnership Building", "Market Expansion"]
    },
    {
      icon: Users,
      title: "Leadership Training",
      description: "Develop strong leaders who can drive your organization to new heights of success.",
      features: ["Executive Coaching", "Team Building", "Skills Development"]
    },
    {
      icon: Globe,
      title: "Digital Transformation",
      description: "Transform your business with cutting-edge digital solutions and technologies.",
      features: ["Process Automation", "Digital Strategy", "Technology Integration"]
    }
  ];

  const stats = [
    { value: "250+", label: "Successful Projects" },
    { value: "150+", label: "Happy Clients" },
    { value: "10+", label: "Years Experience" },
    { value: "95%", label: "Client Satisfaction" }
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "CEO, TechCorp",
      content: "Leadleaders transformed our business strategy and helped us achieve 40% growth in just one year.",
      rating: 5
    },
    {
      name: "Michael Chen",
      role: "Founder, StartupX",
      content: "Their expertise in business development opened doors we never thought possible. Exceptional service!",
      rating: 5
    },
    {
      name: "Emma Davis",
      role: "VP Operations, GlobalTech",
      content: "The leadership training program they provided has significantly improved our team performance.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-6 py-24">
          <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge variant="outline" className="w-fit">
                  Leading Business Solutions
                </Badge>
                <h1 className="text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl">
                  Transform Your Business with
                  <span className="text-primary"> Expert Leadership</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-lg">
                  We help businesses unlock their potential through strategic consulting, 
                  leadership development, and innovative solutions that drive sustainable growth.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="gap-2" asChild>
                  <Link to="/contact">
                    Get Started Today
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg" className="gap-2" asChild>
                  <Link to="/support">
                    <TicketIcon className="h-4 w-4" />
                    Submit Support Ticket
                  </Link>
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="text-2xl font-bold text-primary">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 p-8 flex items-center justify-center">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets%2Fc0b5dede6cf14c76b391d16bf0c6c54e%2F8e2d9ad8617e4cd0b4420a2929dbc6f9?format=webp&width=800"
                  alt="Leadleaders"
                  className="h-64 w-auto"
                />
              </div>
              {/* Floating Elements */}
              <div className="absolute -top-4 -right-4 bg-yellow-400 rounded-full p-3">
                <Award className="h-6 w-6 text-white" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-green-400 rounded-full p-3">
                <Zap className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="outline" className="w-fit mx-auto">Our Services</Badge>
            <h2 className="text-3xl font-bold sm:text-4xl">
              Comprehensive Business Solutions
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From strategic planning to execution, we provide end-to-end solutions 
              that empower your business to thrive in today's competitive landscape.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {services.map((service, index) => (
              <Card key={index} className="relative group hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <service.icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-base">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button variant="ghost" className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="grid gap-12 lg:grid-cols-2 items-center">
            <div className="space-y-6">
              <Badge variant="outline" className="w-fit">About Leadleaders</Badge>
              <h2 className="text-3xl font-bold sm:text-4xl">
                Driving Success Through 
                <span className="text-primary"> Expert Guidance</span>
              </h2>
              <p className="text-lg text-muted-foreground">
                With over a decade of experience in business consulting and leadership development, 
                Leadleaders has helped hundreds of organizations achieve their goals and exceed expectations.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Proven Track Record</h4>
                    <p className="text-muted-foreground">250+ successful projects with measurable results</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Expert Team</h4>
                    <p className="text-muted-foreground">Industry-leading consultants and strategists</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-6 w-6 text-green-500 mt-0.5" />
                  <div>
                    <h4 className="font-semibold">Tailored Solutions</h4>
                    <p className="text-muted-foreground">Customized strategies for your unique challenges</p>
                  </div>
                </div>
              </div>

              <Button size="lg" asChild>
                <Link to="/about">Learn More About Us</Link>
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-6">
                <Card className="p-6">
                  <CardContent className="p-0">
                    <div className="text-3xl font-bold text-primary">95%</div>
                    <div className="text-sm text-muted-foreground">Client Satisfaction Rate</div>
                  </CardContent>
                </Card>
                <Card className="p-6">
                  <CardContent className="p-0">
                    <div className="text-3xl font-bold text-primary">150+</div>
                    <div className="text-sm text-muted-foreground">Happy Clients</div>
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-6 pt-12">
                <Card className="p-6">
                  <CardContent className="p-0">
                    <div className="text-3xl font-bold text-primary">10+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </CardContent>
                </Card>
                <Card className="p-6">
                  <CardContent className="p-0">
                    <div className="text-3xl font-bold text-primary">250+</div>
                    <div className="text-sm text-muted-foreground">Projects Completed</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="outline" className="w-fit mx-auto">Testimonials</Badge>
            <h2 className="text-3xl font-bold sm:text-4xl">
              What Our Clients Say
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Don't just take our word for it. Here's what our satisfied clients have to say about working with Leadleaders.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="relative">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Support Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center space-y-4 mb-12">
              <Badge variant="outline" className="w-fit mx-auto">Customer Support</Badge>
              <h2 className="text-3xl font-bold sm:text-4xl">
                Need Help? We're Here for You
              </h2>
              <p className="text-xl text-muted-foreground">
                Submit a support ticket for any questions, concerns, or technical issues.
                Our dedicated team will get back to you quickly.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="text-center p-6">
                <CardContent className="p-0">
                  <TicketIcon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Submit a Ticket</h3>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Report issues or ask questions through our ticket system
                  </p>
                  <Button className="w-full" asChild>
                    <Link to="/support">Submit Ticket</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="text-center p-6">
                <CardContent className="p-0">
                  <Phone className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Call Support</h3>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Speak directly with our support team
                  </p>
                  <Button variant="outline" className="w-full">
                    +1 (555) 123-4567
                  </Button>
                </CardContent>
              </Card>

              <Card className="text-center p-6">
                <CardContent className="p-0">
                  <Mail className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Email Us</h3>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Send us an email for detailed inquiries
                  </p>
                  <Button variant="outline" className="w-full">
                    support@leadleaders.com
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-3xl font-bold sm:text-4xl">
              Ready to Transform Your Business?
            </h2>
            <p className="text-xl opacity-90">
              Let's discuss how Leadleaders can help you achieve your business goals 
              and unlock your organization's full potential.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" variant="secondary" className="gap-2" asChild>
                <Link to="/contact">
                  <Mail className="h-4 w-4" />
                  Get Free Consultation
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="gap-2 bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                <Phone className="h-4 w-4" />
                Call Now: +1 (555) 123-4567
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
