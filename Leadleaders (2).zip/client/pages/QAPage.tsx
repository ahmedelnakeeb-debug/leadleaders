import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function QAPage() {
  const qaDepartment = departments.find(dept => dept.id === 'qa')!;
  return <DepartmentPage department={qaDepartment} />;
}
