import PlaceholderPage from '@/components/PlaceholderPage';
import { Briefcase } from 'lucide-react';

export default function ServicesPage() {
  return (
    <PlaceholderPage
      title="Our Services"
      description="Comprehensive business solutions designed to accelerate your growth and drive sustainable success."
      comingSoonText="We're crafting detailed information about our consulting services, strategic planning solutions, and business development programs. This page will showcase our full range of offerings soon!"
      icon={<Briefcase className="h-8 w-8" />}
    />
  );
}
