import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function HRPage() {
  const hrDepartment = departments.find(dept => dept.id === 'hr')!;
  return <DepartmentPage department={hrDepartment} />;
}
