import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function BusinessDevelopmentPage() {
  const businessDevelopmentDepartment = departments.find(dept => dept.id === 'business-development')!;
  return <DepartmentPage department={businessDevelopmentDepartment} />;
}
