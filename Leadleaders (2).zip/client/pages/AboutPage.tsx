import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import {
  Target,
  Users,
  Award,
  TrendingUp,
  CheckCircle,
  ArrowRight,
} from 'lucide-react';

export default function AboutPage() {
  const values = [
    {
      icon: Target,
      title: "Excellence",
      description: "We strive for excellence in everything we do, delivering exceptional results that exceed expectations."
    },
    {
      icon: Users,
      title: "Collaboration",
      description: "We believe in the power of collaboration, working closely with our clients to achieve shared success."
    },
    {
      icon: Award,
      title: "Innovation",
      description: "We embrace innovation and cutting-edge solutions to solve complex business challenges."
    },
    {
      icon: TrendingUp,
      title: "Growth",
      description: "We are committed to driving sustainable growth for our clients and their organizations."
    }
  ];

  const milestones = [
    { year: "2014", title: "Company Founded", description: "Leadleaders was established with a vision to transform businesses through expert consulting." },
    { year: "2017", title: "100 Clients Milestone", description: "Reached our first major milestone of serving 100 satisfied clients across various industries." },
    { year: "2020", title: "Digital Transformation", description: "Expanded our services to include comprehensive digital transformation solutions." },
    { year: "2024", title: "Industry Recognition", description: "Recognized as a leading consulting firm with 250+ successful projects completed." }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <Badge variant="outline" className="w-fit mx-auto">About Leadleaders</Badge>
            <h1 className="text-4xl font-bold sm:text-5xl lg:text-6xl">
              Leading Businesses to
              <span className="text-primary"> Unprecedented Success</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              For over a decade, Leadleaders has been at the forefront of business transformation, 
              helping organizations unlock their potential and achieve sustainable growth through 
              strategic consulting and innovative solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="grid gap-12 lg:grid-cols-2">
            <Card className="p-8">
              <CardHeader className="p-0 mb-6">
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <p className="text-lg text-muted-foreground">
                  To empower businesses of all sizes to achieve their full potential through 
                  strategic consulting, innovative solutions, and expert guidance that drives 
                  measurable results and sustainable growth.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8">
              <CardHeader className="p-0 mb-6">
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <p className="text-lg text-muted-foreground">
                  To be the world's most trusted business consulting partner, recognized for 
                  our ability to transform challenges into opportunities and help organizations 
                  become leaders in their respective industries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="outline" className="w-fit mx-auto">Our Values</Badge>
            <h2 className="text-3xl font-bold sm:text-4xl">
              The Principles That Guide Us
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our core values shape every decision we make and every solution we deliver, 
              ensuring we always act in the best interest of our clients.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {values.map((value, index) => (
              <Card key={index} className="text-center p-6">
                <CardContent className="p-0">
                  <div className="mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <value.icon className="h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <Badge variant="outline" className="w-fit mx-auto">Our Journey</Badge>
            <h2 className="text-3xl font-bold sm:text-4xl">
              A Decade of Excellence
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From our humble beginnings to becoming an industry leader, 
              here are the key milestones that define our journey.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex gap-6 items-start">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                      {milestone.year.slice(-2)}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="bg-card rounded-lg p-6 border">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-semibold">{milestone.title}</h3>
                        <Badge variant="secondary">{milestone.year}</Badge>
                      </div>
                      <p className="text-muted-foreground">{milestone.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-24 bg-primary text-primary-foreground">
        <div className="container mx-auto px-6">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl font-bold sm:text-4xl">
              Our Impact in Numbers
            </h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              These numbers represent the trust our clients place in us and 
              the results we've achieved together.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-4">
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">250+</div>
              <div className="text-lg opacity-90">Successful Projects</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">150+</div>
              <div className="text-lg opacity-90">Happy Clients</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">10+</div>
              <div className="text-lg opacity-90">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">95%</div>
              <div className="text-lg opacity-90">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold sm:text-4xl">
              Ready to Work with Us?
            </h2>
            <p className="text-xl text-muted-foreground">
              Let's discuss how Leadleaders can help transform your business 
              and achieve your strategic objectives.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" className="gap-2" asChild>
                <Link to="/contact">
                  Start Your Journey
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="/services">View Our Services</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
