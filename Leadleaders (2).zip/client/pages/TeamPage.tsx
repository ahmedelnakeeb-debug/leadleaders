import PlaceholderPage from '@/components/PlaceholderPage';
import { Users } from 'lucide-react';

export default function TeamPage() {
  return (
    <PlaceholderPage
      title="Our Team"
      description="Meet the experienced professionals who drive innovation and deliver exceptional results for our clients."
      comingSoonText="We're preparing detailed profiles of our expert consultants, their specializations, and success stories. Get ready to meet the team that will transform your business!"
      icon={<Users className="h-8 w-8" />}
    />
  );
}
