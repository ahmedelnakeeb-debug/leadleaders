import PlaceholderPage from '@/components/PlaceholderPage';
import { Mail } from 'lucide-react';

export default function ContactPage() {
  return (
    <PlaceholderPage
      title="Contact Us"
      description="Ready to transform your business? Get in touch with our team to discuss your goals and discover how we can help."
      comingSoonText="We're building an interactive contact form and comprehensive contact information page. For now, you can reach us directly at info@leadleaders.com or +1 (555) 123-4567!"
      icon={<Mail className="h-8 w-8" />}
    />
  );
}
