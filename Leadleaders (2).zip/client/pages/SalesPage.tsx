import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function SalesPage() {
  const salesDepartment = departments.find(dept => dept.id === 'sales')!;
  return <DepartmentPage department={salesDepartment} />;
}
