import DepartmentPage from '@/components/DepartmentPage';
import { departments } from '@/lib/types';

export default function CSMPage() {
  const csmDepartment = departments.find(dept => dept.id === 'csm')!;
  return <DepartmentPage department={csmDepartment} />;
}
