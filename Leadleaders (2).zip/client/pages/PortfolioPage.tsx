import PlaceholderPage from '@/components/PlaceholderPage';
import { Trophy } from 'lucide-react';

export default function PortfolioPage() {
  return (
    <PlaceholderPage
      title="Our Portfolio"
      description="Explore our successful projects and the measurable impact we've created for businesses across various industries."
      comingSoonText="We're compiling case studies, client success stories, and project highlights that demonstrate our expertise and proven track record. Check back soon for inspiring transformation stories!"
      icon={<Trophy className="h-8 w-8" />}
    />
  );
}
